const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
canvas.width = 320;
canvas.height = 480;

let frames = 0;
const DEGREE = Math.PI / 180;

const bird = {
  x: 50,
  y: 150,
  w: 34,
  h: 26,
  gravity: 0.25,
  jump: 4.6,
  velocity: 0,
  draw() {
    ctx.fillStyle = "yellow";
    ctx.fillRect(this.x, this.y, this.w, this.h);
  },
  flap() {
    this.velocity = -this.jump;
  },
  update() {
    this.velocity += this.gravity;
    this.y += this.velocity;

    if (this.y + this.h >= canvas.height) {
      this.y = canvas.height - this.h;
      this.velocity = 0;
    }
  }
};

const pipes = [];
let pipeGap = 100;
let pipeWidth = 50;
let pipeSpeed = 2;
let score = 0;
let gameOver = false;

function spawnPipe() {
  const top = Math.random() * (canvas.height - pipeGap - 50) + 20;
  pipes.push({
    x: canvas.width,
    topY: top,
    bottomY: top + pipeGap
  });
}

function updatePipes() {
  for (let i = 0; i < pipes.length; i++) {
    pipes[i].x -= pipeSpeed;

    if (
      bird.x < pipes[i].x + pipeWidth &&
      bird.x + bird.w > pipes[i].x &&
      (bird.y < pipes[i].topY || bird.y + bird.h > pipes[i].bottomY)
    ) {
      gameOver = true;
    }

    if (pipes[i].x + pipeWidth === bird.x) {
      score++;
    }
  }

  if (pipes.length > 0 && pipes[0].x + pipeWidth < 0) {
    pipes.shift();
  }

  if (frames % 100 === 0) {
    spawnPipe();
  }
}

function drawPipes() {
  ctx.fillStyle = "#00FF00";
  pipes.forEach(pipe => {
    ctx.fillRect(pipe.x, 0, pipeWidth, pipe.topY);
    ctx.fillRect(pipe.x, pipe.bottomY, pipeWidth, canvas.height - pipe.bottomY);
  });
}

function drawScore() {
  ctx.fillStyle = "#000";
  ctx.font = "20px Arial";
  ctx.fillText("Score: " + score, 10, 30);
}

function loop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  bird.update();
  bird.draw();

  updatePipes();
  drawPipes();

  drawScore();

  frames++;
  if (!gameOver) {
    requestAnimationFrame(loop);
  } else {
    ctx.fillStyle = "red";
    ctx.font = "30px Arial";
    ctx.fillText("Game Over", 90, 220);
  }
}

canvas.addEventListener("click", () => {
  if (!gameOver) bird.flap();
  else window.location.reload();
});

spawnPipe();
loop();
